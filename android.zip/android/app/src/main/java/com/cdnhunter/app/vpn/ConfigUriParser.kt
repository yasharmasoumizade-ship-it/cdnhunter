package com.cdnhunter.app.vpn

import android.util.Base64
import org.json.JSONObject
import java.net.URLDecoder

/**
 * Parses a proxy URI (vless:// trojan:// vmess:// ss://) into the flat
 * key-value shape mihomo/Clash expects under `proxies:` in its YAML config.
 * Unlike Xray, mihomo has no separate streamSettings/tls block — transport,
 * TLS and REALITY options all live directly on the proxy object.
 */
object ConfigUriParser {

    /** Returns a LinkedHashMap ready to be YAML-serialized as one `proxies:` entry, or null.
     *  forceX25519Mlkem768: only meaningful for reality proxies — see applyTransport(). */
    fun parseToProxy(uri: String, forceX25519Mlkem768: Boolean = false): LinkedHashMap<String, Any>? {
        val trimmed = uri.trim()
        return when {
            trimmed.startsWith("trojan://") -> parseTrojan(trimmed)
            trimmed.startsWith("vless://") -> parseVless(trimmed, forceX25519Mlkem768)
            trimmed.startsWith("vmess://") -> parseVmess(trimmed)
            trimmed.startsWith("ss://") -> parseShadowsocks(trimmed)
            else -> null
        }
    }

    private fun parseTrojan(uri: String): LinkedHashMap<String, Any> {
        val body = uri.removePrefix("trojan://")
        val password = body.substringBefore("@")
        val rest = body.substringAfter("@").substringBefore("#")
        val hostPort = rest.substringBefore("?")
        val query = if (rest.contains("?")) rest.substringAfter("?") else ""
        val (address, port) = splitHostPort(hostPort, 443)
        val params = parseQuery(query)

        val p = linkedMapOf<String, Any>(
            "name" to "trojan-out",
            "type" to "trojan",
            "server" to address,
            "port" to port,
            "password" to password,
            "udp" to true,
        )
        val sni = params["sni"] ?: params["peer"] ?: ""
        if (sni.isNotBlank()) p["sni"] = sni
        if ((params["allowInsecure"] ?: params["insecure"]) == "1") p["skip-cert-verify"] = true
        applyTransport(p, params)
        return p
    }

    private fun parseVless(uri: String, forceX25519Mlkem768: Boolean = false): LinkedHashMap<String, Any> {
        val body = uri.removePrefix("vless://")
        val uuid = body.substringBefore("@")
        val rest = body.substringAfter("@").substringBefore("#")
        val hostPort = rest.substringBefore("?")
        val query = if (rest.contains("?")) rest.substringAfter("?") else ""
        val (address, port) = splitHostPort(hostPort, 443)
        val params = parseQuery(query)

        val p = linkedMapOf<String, Any>(
            "name" to "vless-out",
            "type" to "vless",
            "server" to address,
            "port" to port,
            "uuid" to uuid,
            "udp" to true,
        )
        val flow = params["flow"] ?: ""
        if (flow.isNotBlank()) p["flow"] = flow
        applyTransport(p, params, forceX25519Mlkem768)
        return p
    }

    private fun parseVmess(uri: String): LinkedHashMap<String, Any> {
        val b64 = uri.removePrefix("vmess://")
        val json = String(Base64.decode(padBase64(b64), Base64.DEFAULT))
        val obj = JSONObject(json)

        val p = linkedMapOf<String, Any>(
            "name" to "vmess-out",
            "type" to "vmess",
            "server" to obj.optString("add"),
            "port" to (obj.optString("port").toIntOrNull() ?: 443),
            "uuid" to obj.optString("id"),
            "alterId" to (obj.optString("aid", "0").toIntOrNull() ?: 0),
            "cipher" to obj.optString("scy", "auto"),
            "udp" to true,
        )
        val params = mapOf(
            "type" to obj.optString("net", "tcp"),
            "security" to obj.optString("tls", ""),
            "sni" to obj.optString("sni", ""),
            "host" to obj.optString("host", ""),
            "path" to obj.optString("path", ""),
            "alpn" to obj.optString("alpn", ""),
            "fp" to obj.optString("fp", ""),
        )
        applyTransport(p, params)
        return p
    }

    private fun parseShadowsocks(uri: String): LinkedHashMap<String, Any>? {
        val body = uri.removePrefix("ss://")
        val withoutTag = body.substringBefore("#")
        val hasAt = withoutTag.contains("@")

        val method: String
        val password: String
        val hostPortRaw: String

        if (hasAt) {
            val userInfo = withoutTag.substringBefore("@")
            hostPortRaw = withoutTag.substringAfter("@")
            val decodedUserInfo = try {
                String(Base64.decode(padBase64(userInfo), Base64.URL_SAFE or Base64.NO_WRAP))
            } catch (e: Exception) {
                try { String(Base64.decode(padBase64(userInfo), Base64.DEFAULT)) }
                catch (e2: Exception) { userInfo }
            }
            val credSource = if (decodedUserInfo.contains(":")) decodedUserInfo else userInfo
            method = credSource.substringBefore(":")
            password = credSource.substringAfter(":")
        } else {
            val decoded = try {
                String(Base64.decode(padBase64(withoutTag), Base64.DEFAULT))
            } catch (e: Exception) { return null }
            if (!decoded.contains("@")) return null
            val credPart = decoded.substringBefore("@")
            hostPortRaw = decoded.substringAfter("@")
            method = credPart.substringBefore(":")
            password = credPart.substringAfter(":")
        }

        val hostPortClean = hostPortRaw.substringBefore("?").substringBefore("#")
        val (address, port) = splitHostPort(hostPortClean, 8388)
        if (address.isBlank() || method.isBlank() || password.isBlank()) return null

        return linkedMapOf(
            "name" to "ss-out",
            "type" to "ss",
            "server" to address,
            "port" to port,
            "cipher" to method,
            "password" to password,
            "udp" to true,
        )
    }

    private fun padBase64(s: String): String {
        var str = s.replace('-', '+').replace('_', '/')
        val mod = str.length % 4
        if (mod > 0) str += "=".repeat(4 - mod)
        return str
    }

    /**
     * Splits an authority into address + port.
     *
     * `substringBeforeLast(":")` / `substringAfterLast(":")` was close enough for
     * `host:port`, but it reads the port out of whatever follows the last colon
     * regardless of whether that is a number — so a bracketed IPv6 authority with
     * no port (`[2001:db8::1]`) came back as the address `[2001:db8:` with the
     * protocol default stapled on. The port shown on Home is the one this returns,
     * so it has to be the config's own port or an admitted default, never a
     * fragment of the host misread as one.
     *
     * Brackets are kept on IPv6 literals, which is what the old code did and what
     * mihomo accepts.
     */
    private fun splitHostPort(authority: String, defaultPort: Int): Pair<String, Int> {
        val trimmed = authority.trim()
        if (trimmed.startsWith("[")) {
            val close = trimmed.indexOf(']')
            if (close > 0) {
                val host = trimmed.substring(0, close + 1)
                val port = trimmed.substring(close + 1).removePrefix(":").toIntOrNull()
                return host to (port ?: defaultPort)
            }
        }
        val colon = trimmed.lastIndexOf(':')
        if (colon > 0) {
            val port = trimmed.substring(colon + 1).toIntOrNull()
            if (port != null) return trimmed.substring(0, colon) to port
        }
        return trimmed to defaultPort
    }

    /** Applies TLS/REALITY + transport (ws/grpc/h2/tcp) settings directly onto the flat proxy map.
     *  forceX25519Mlkem768: whether to set reality-opts.support-x25519mlkem768 for a
     *  "reality" security block. This can't be a fixed value — some Xray-core server
     *  versions (v26.7.11+) require it, but forcing it on against a server that doesn't
     *  expect the post-quantum ClientHello computes a mismatched shared secret and fails
     *  auth outright (REALITY's handshake is a strict binary match, not a soft TLS
     *  negotiation with a graceful fallback). The caller (CdnVpnService) tries false
     *  first and retries with true only if the first attempt's coreLog shows
     *  "REALITY authentication failed". */
    private fun applyTransport(p: LinkedHashMap<String, Any>, params: Map<String, String>, forceX25519Mlkem768: Boolean = false) {
        val network = params["type"] ?: "tcp"
        val security = params["security"] ?: ""

        when (security) {
            "tls" -> {
                p["tls"] = true
                val sni = params["sni"] ?: params["host"] ?: ""
                if (sni.isNotBlank()) p["servername"] = sni
                val alpn = params["alpn"] ?: ""
                if (alpn.isNotBlank()) p["alpn"] = alpn.split(",").filter { it.isNotBlank() }
                if ((params["allowInsecure"] ?: params["insecure"]) == "1") p["skip-cert-verify"] = true

                // ECH (Encrypted Client Hello) -- mihomo's vless outbound applies
                // ClientFingerprint and ECH together with no conflict (see upstream
                // adapter/outbound/vless.go: both fields sit side by side on the same
                // TLSConfig struct), so both are always emitted when present.
                val ech = params["ech"] ?: ""
                if (ech.isNotBlank()) {
                    p["ech-opts"] = linkedMapOf<String, Any>(
                        "enable" to true,
                        "config" to ech
                    )
                }
                val fp = params["fp"] ?: ""
                if (fp.isNotBlank()) p["client-fingerprint"] = fp
            }
            "reality" -> {
                p["tls"] = true
                val sni = params["sni"] ?: ""
                if (sni.isNotBlank()) p["servername"] = sni
                p["client-fingerprint"] = params["fp"]?.takeIf { it.isNotBlank() } ?: "chrome"
                val realityOpts = linkedMapOf<String, Any>()
                (params["pbk"] ?: "").takeIf { it.isNotBlank() }?.let { realityOpts["public-key"] = it }
                (params["sid"] ?: "").let { realityOpts["short-id"] = it } // mihomo accepts empty short-id
                if (forceX25519Mlkem768) realityOpts["support-x25519mlkem768"] = true
                if (realityOpts.isNotEmpty()) p["reality-opts"] = realityOpts
                // Note: "spx" (REALITY spider-x path) has no mihomo equivalent field
                // and is silently dropped -- it only affects what a passive prober
                // sees when it fetches the REALITY target site directly, not the
                // proxy handshake itself, so omitting it does not break the connection.
            }
        }

        when (network) {
            "ws" -> {
                p["network"] = "ws"
                val wsOpts = linkedMapOf<String, Any>("path" to (params["path"]?.takeIf { it.isNotBlank() } ?: "/"))
                val host = params["host"] ?: ""
                if (host.isNotBlank()) wsOpts["headers"] = linkedMapOf("Host" to host)
                p["ws-opts"] = wsOpts
            }
            "grpc" -> {
                p["network"] = "grpc"
                val serviceName = params["serviceName"] ?: params["path"] ?: ""
                p["grpc-opts"] = linkedMapOf("grpc-service-name" to serviceName)
            }
            "h2", "http" -> {
                p["network"] = "h2"
                val h2Opts = linkedMapOf<String, Any>("path" to listOf(params["path"]?.takeIf { it.isNotBlank() } ?: "/"))
                val host = params["host"] ?: ""
                if (host.isNotBlank()) h2Opts["host"] = listOf(host)
                p["h2-opts"] = h2Opts
            }
            "xhttp", "splithttp" -> {
                p["network"] = "xhttp"
                val xhttpOpts = linkedMapOf<String, Any>(
                    "path" to (params["path"]?.takeIf { it.isNotBlank() } ?: "/"),
                    "mode" to (params["mode"]?.takeIf { it.isNotBlank() } ?: "auto"),
                )
                val host = params["host"] ?: ""
                if (host.isNotBlank()) xhttpOpts["host"] = host
                p["xhttp-opts"] = xhttpOpts
            }
            // "tcp" (the default) needs no network/*-opts entry in mihomo.
        }
    }

    private fun parseQuery(query: String): Map<String, String> {
        if (query.isBlank()) return emptyMap()
        return query.split("&").associate { part ->
            val k = part.substringBefore("=")
            val v = try { URLDecoder.decode(part.substringAfter("="), "UTF-8") } catch (_: Exception) { part.substringAfter("=") }
            k to v
        }
    }

    /**
     * The transport the config actually dials, named for a human: "Reality",
     * "WebSocket", "gRPC", "HTTP/2", "XHTTP", "TLS" or "TCP".
     *
     * Home's status row used to print [SavedConfig.proto] — the base protocol, always
     * "VLESS" for the configs this app is handed — which said nothing that distinguished
     * one server from another. The transport does: it is the thing that decides whether a
     * server survives a given network, and it is the field a user comparing two configs
     * actually reads.
     *
     * REALITY is reported ahead of the stream type on purpose. It is a TLS *replacement*
     * rather than a transport, so a reality config's stream is usually plain TCP and
     * "TCP" would be the least informative true thing this could say about it. Where both
     * exist — reality over gRPC, reality over ws — the transport is named after it
     * ("Reality · gRPC"), so nothing is lost by leading with the part that matters.
     *
     * Read from the URI rather than from the parsed proxy map: mihomo expresses REALITY
     * as `reality-opts` beside `tls: true` and omits `network` entirely for TCP, so
     * neither the security mode nor the plain-TCP case survives into
     * [SavedConfig.network]. Anything this can't read — a vmess payload it can't decode,
     * an unknown scheme, a URI with no query at all — comes back "TCP", which is what an
     * unadorned proxy is.
     */
    fun transportOf(uri: String): String {
        val trimmed = uri.trim()
        val params: Map<String, String> = if (trimmed.startsWith("vmess://")) {
            // vmess carries its settings as base64 JSON, not as a query string.
            try {
                val obj = JSONObject(String(Base64.decode(padBase64(trimmed.removePrefix("vmess://")), Base64.DEFAULT)))
                mapOf(
                    "type" to obj.optString("net", "tcp"),
                    "security" to obj.optString("tls", ""),
                )
            } catch (e: Exception) {
                emptyMap()
            }
        } else {
            val rest = trimmed.substringAfter("@", "").substringBefore("#")
            if (rest.contains("?")) parseQuery(rest.substringAfter("?")) else emptyMap()
        }

        val security = (params["security"] ?: "").lowercase()
        val stream = when ((params["type"] ?: "").lowercase()) {
            "ws", "websocket" -> "WebSocket"
            "grpc" -> "gRPC"
            "h2", "http" -> "HTTP/2"
            "xhttp", "splithttp" -> "XHTTP"
            "quic" -> "QUIC"
            else -> ""
        }
        return when {
            security == "reality" -> if (stream.isNotBlank()) "Reality · $stream" else "Reality"
            stream.isNotBlank() -> stream
            security == "tls" -> "TLS"
            // ss:// has no transport of its own, and a config whose URI carried no
            // stream settings is a plain connection — both are TCP.
            else -> "TCP"
        }
    }
}

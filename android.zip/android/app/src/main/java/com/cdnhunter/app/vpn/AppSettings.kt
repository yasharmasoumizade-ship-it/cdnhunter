package com.cdnhunter.app.vpn

import android.content.Context

/**
 * Persisted app settings that actually change VPN/app behavior -- as opposed
 * to the old Settings screen rows (auto-reconnect, kill switch toggle,
 * protocol row, etc.) that rendered a UI control wired to nothing. Every
 * field here is read by either VpnConfigBuilder (mihomo YAML) or
 * CdnVpnService (Android VpnService.Builder) and actually changes what gets
 * built.
 */
object AppSettings {
    // Kept in sync with SecurePrefs.SETTINGS — that object owns opening this file and
    // migrating it out of plaintext, since subscriptions live here.
    private const val PREFS = SecurePrefs.SETTINGS

    private const val KEY_USE_DOH = "use_doh"
    private const val KEY_KILL_SWITCH = "kill_switch"
    private const val KEY_ALLOW_LAN = "allow_lan"
    private const val KEY_IPV6 = "ipv6_enabled"
    private const val KEY_MTU = "mtu"
    private const val KEY_MTU_PRESET = "mtu_preset"
    private const val KEY_LANGUAGE = "language" // "en" or "fa"
    private const val KEY_SPLIT_TUNNEL_APPS = "split_tunnel_apps"
    private const val KEY_SPLIT_TUNNEL_MODE = "split_tunnel_mode" // "exclude" or "include"
    
    // Ad Blocker (R.O.B.E.R.T style)
    private const val KEY_AD_BLOCKER_ENABLED = "ad_blocker_enabled"
    private const val KEY_BLOCK_ADS = "block_ads"
    private const val KEY_BLOCK_TRACKERS = "block_trackers"
    private const val KEY_BLOCK_MALWARE = "block_malware"
    private const val KEY_CUSTOM_BLOCKLISTS = "custom_blocklists"

    // Malware Blocker — an independent feature, NOT a sub-option of the ad blocker.
    // Its own master toggle so threat protection can be on with ad filtering off.
    private const val KEY_MALWARE_BLOCKER_ENABLED = "malware_blocker_enabled"
    
    // Appearance
    private const val KEY_THEME = "theme" // "light", "dark", "auto"
    private const val KEY_ACCENT_COLOR = "accent_color"
    private const val KEY_AMOLED_MODE = "amoled_mode"
    
    // Custom DNS
    private const val KEY_CUSTOM_DNS_ENABLED = "custom_dns_enabled"
    private const val KEY_CUSTOM_DNS_SERVERS = "custom_dns_servers"  // comma-separated
    private const val KEY_PRIMARY_DNS = "primary_dns"
    private const val KEY_SECONDARY_DNS = "secondary_dns"
    
    // Server Management
    private const val KEY_FAVORITE_SERVERS = "favorite_servers"
    private const val KEY_CUSTOM_SERVER_NAMES = "custom_server_names"
    
    // Auto-Reconnect
    private const val KEY_AUTO_RECONNECT_ENABLED = "auto_reconnect_enabled"
    private const val KEY_MAX_RETRY_ATTEMPTS = "max_retry_attempts"

    // Which server the Home power button acts on: the one the user picked
    // ("manual") or the best-measuring one the app picks for them ("smart").
    // Stored as a string rather than the UI's own ConnectMode enum so this file
    // keeps knowing nothing about the ui package.
    private const val KEY_CONNECT_MODE = "connect_mode"

    const val DEFAULT_MTU = 1500  // standard Ethernet MTU (matches v2rayNG)
    const val MIN_MTU = 576       // smallest MTU any IPv4 path is guaranteed to carry
    const val MAX_MTU = 9000      // jumbo-frame ceiling (allow custom up to 9000)

    // Theme modes
    const val THEME_LIGHT = "light"
    const val THEME_DARK = "dark"
    const val THEME_SYSTEM = "system"

    // Connect modes — see KEY_CONNECT_MODE above.
    const val MODE_SMART = "smart"
    const val MODE_MANUAL = "manual"

    private fun prefs(ctx: Context) = SecurePrefs.get(ctx, PREFS)

    fun useDoh(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_USE_DOH, true)
    fun setUseDoh(ctx: Context, value: Boolean) = prefs(ctx).edit().putBoolean(KEY_USE_DOH, value).apply()

    fun killSwitchEnabled(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_KILL_SWITCH, true)
    fun setKillSwitchEnabled(ctx: Context, value: Boolean) = prefs(ctx).edit().putBoolean(KEY_KILL_SWITCH, value).apply()

    fun allowLan(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_ALLOW_LAN, false)
    fun setAllowLan(ctx: Context, value: Boolean) = prefs(ctx).edit().putBoolean(KEY_ALLOW_LAN, value).apply()

    fun ipv6Enabled(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_IPV6, false)
    fun setIpv6Enabled(ctx: Context, value: Boolean) = prefs(ctx).edit().putBoolean(KEY_IPV6, value).apply()

    fun mtu(ctx: Context): Int = prefs(ctx).getInt(KEY_MTU, DEFAULT_MTU)
    fun setMtu(ctx: Context, value: Int) =
        prefs(ctx).edit().putInt(KEY_MTU, value.coerceIn(MIN_MTU, MAX_MTU)).apply()

    fun language(ctx: Context): String = prefs(ctx).getString(KEY_LANGUAGE, "fa") ?: "fa"
    fun setLanguage(ctx: Context, value: String) = prefs(ctx).edit().putString(KEY_LANGUAGE, value).apply()

    // Split tunneling: a set of package names, and whether that set is
    // EXCLUDED from the tunnel (VPN off just for these apps, on for
    // everything else -- Windscribe's more common mode, e.g. excluding a
    // banking app) or the ONLY apps INCLUDED (VPN only for these, off for
    // everything else -- useful for routing just one app through the VPN
    // without affecting the rest of the device). Empty set + "exclude" mode
    // (the default) means no split tunneling at all -- every app uses the
    // VPN, matching current behavior for anyone who never touches this.
    fun splitTunnelMode(ctx: Context): String = prefs(ctx).getString(KEY_SPLIT_TUNNEL_MODE, "exclude") ?: "exclude"
    fun setSplitTunnelMode(ctx: Context, mode: String) = prefs(ctx).edit().putString(KEY_SPLIT_TUNNEL_MODE, mode).apply()

    fun splitTunnelApps(ctx: Context): Set<String> = prefs(ctx).getStringSet(KEY_SPLIT_TUNNEL_APPS, emptySet()) ?: emptySet()
    fun setSplitTunnelApps(ctx: Context, packages: Set<String>) =
        // getStringSet/putStringSet share the underlying mutable Set instance
        // in some SharedPreferences implementations, which can silently
        // corrupt stored data if the caller mutates a set they got from
        // getStringSet() and passes it back without copying. Defensively
        // copy here so callers don't need to know about that footgun.
        prefs(ctx).edit().putStringSet(KEY_SPLIT_TUNNEL_APPS, HashSet(packages)).apply()

    // ============ MTU Preset ============
    fun mtuPreset(ctx: Context): String = prefs(ctx).getString(KEY_MTU_PRESET, "iran_isp") ?: "iran_isp"
    fun setMtuPreset(ctx: Context, preset: String) = prefs(ctx).edit().putString(KEY_MTU_PRESET, preset).apply()

    // ============ Ad Blocker Settings ============
    fun adBlockerEnabled(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_AD_BLOCKER_ENABLED, true)
    fun setAdBlockerEnabled(ctx: Context, value: Boolean) = prefs(ctx).edit().putBoolean(KEY_AD_BLOCKER_ENABLED, value).apply()

    fun blockAds(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_BLOCK_ADS, true)
    fun setBlockAds(ctx: Context, value: Boolean) = prefs(ctx).edit().putBoolean(KEY_BLOCK_ADS, value).apply()

    fun blockTrackers(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_BLOCK_TRACKERS, true)
    fun setBlockTrackers(ctx: Context, value: Boolean) = prefs(ctx).edit().putBoolean(KEY_BLOCK_TRACKERS, value).apply()

    fun blockMalware(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_BLOCK_MALWARE, true)
    fun setBlockMalware(ctx: Context, value: Boolean) = prefs(ctx).edit().putBoolean(KEY_BLOCK_MALWARE, value).apply()

    // Independent Malware Blocker master switch. Opt-in (default off), like the ad blocker,
    // so no unexpected rule-provider download happens for users who never enable it. Read
    // directly by VpnConfigBuilder to gate the malware rule-provider + REJECT rule, entirely
    // separately from adBlockerEnabled.
    fun malwareBlockerEnabled(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_MALWARE_BLOCKER_ENABLED, false)
    fun setMalwareBlockerEnabled(ctx: Context, value: Boolean) = prefs(ctx).edit().putBoolean(KEY_MALWARE_BLOCKER_ENABLED, value).apply()

    fun customBlocklists(ctx: Context): Set<String> = prefs(ctx).getStringSet(KEY_CUSTOM_BLOCKLISTS, emptySet()) ?: emptySet()
    fun setCustomBlocklists(ctx: Context, urls: Set<String>) = prefs(ctx).edit().putStringSet(KEY_CUSTOM_BLOCKLISTS, HashSet(urls)).apply()

    // ============ Appearance Settings ============
    fun theme(ctx: Context): String = prefs(ctx).getString(KEY_THEME, "auto") ?: "auto"
    fun setTheme(ctx: Context, value: String) = prefs(ctx).edit().putString(KEY_THEME, value).apply()

    fun accentColor(ctx: Context): Int = prefs(ctx).getInt(KEY_ACCENT_COLOR, 0xFF2196F3.toInt())
    fun setAccentColor(ctx: Context, value: Int) = prefs(ctx).edit().putInt(KEY_ACCENT_COLOR, value).apply()

    fun amoledMode(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_AMOLED_MODE, false)
    fun setAmoledMode(ctx: Context, value: Boolean) = prefs(ctx).edit().putBoolean(KEY_AMOLED_MODE, value).apply()

    // ============ Custom DNS Settings ============
    fun customDnsEnabled(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_CUSTOM_DNS_ENABLED, false)
    fun setCustomDnsEnabled(ctx: Context, value: Boolean) = prefs(ctx).edit().putBoolean(KEY_CUSTOM_DNS_ENABLED, value).apply()

    // Returns list of custom DNS servers; defaults to empty (use default 1.1.1.1, 8.8.8.8)
    // Only returns servers that are actually set (not defaults).
    fun customDnsServers(ctx: Context): List<String> {
        val primary = primaryDns(ctx).takeIf { it.isNotBlank() && isValidDnsServer(it) } ?: return emptyList()
        val secondary = secondaryDns(ctx).takeIf { it.isNotBlank() && isValidDnsServer(it) }
        
        return if (secondary != null) listOf(primary, secondary) else listOf(primary)
    }
    
    fun setCustomDnsServers(ctx: Context, servers: List<String>) {
        // Deprecated: use setPrimaryDns/setSecondaryDns instead for better validation
        val validated = servers.filter { isValidDnsServer(it) }
        if (validated.isNotEmpty()) setPrimaryDns(ctx, validated[0])
        if (validated.size > 1) setSecondaryDns(ctx, validated[1])
    }
    
    // Primary DNS (e.g., 8.8.8.8 or https://8.8.8.8/dns-query). Defaults to
    // BLANK, not a real server — a non-blank default here used to mean
    // customDnsServers() always returned a "custom" server the moment the
    // toggle was flipped on, even if the user never typed anything. The
    // input field's placeholder (see AppScreen.kt) shows an example value
    // for guidance; it is not a silently-active default.
    fun primaryDns(ctx: Context): String = prefs(ctx).getString(KEY_PRIMARY_DNS, "") ?: ""
    fun setPrimaryDns(ctx: Context, value: String) = prefs(ctx).edit().putString(KEY_PRIMARY_DNS, value.trim()).apply()
    
    // Secondary DNS (e.g., 8.8.4.4 or https://8.8.4.4/dns-query) - optional, same reasoning as primaryDns above.
    fun secondaryDns(ctx: Context): String = prefs(ctx).getString(KEY_SECONDARY_DNS, "") ?: ""
    fun setSecondaryDns(ctx: Context, value: String) = prefs(ctx).edit().putString(KEY_SECONDARY_DNS, value.trim()).apply()
    
    /**
     * Validates DNS server format. Accepts:
     * - Plain IP: 8.8.8.8
     * - IP with port: 8.8.8.8:53
     * - DoH: https://8.8.8.8/dns-query
     * - DoQ: quic://8.8.8.8:853
     */
    fun isValidDnsServer(server: String): Boolean {
        val trimmed = server.trim()
        if (trimmed.isBlank()) return false
        
        return when {
            // DoH: https://...
            trimmed.startsWith("https://") -> trimmed.length > 11 && trimmed.contains("/dns-query")
            // DoQ: quic://...
            trimmed.startsWith("quic://") -> trimmed.length > 7
            // IP or IP:port
            else -> {
                val parts = trimmed.split(":")
                if (parts.isEmpty() || parts.size > 2) return false
                // Validate IP format (simple check: 4 groups of 1-3 digits separated by dots)
                val ipParts = parts[0].split(".")
                if (ipParts.size != 4) return false
                ipParts.all { it.matches(Regex("\\d{1,3}")) && it.toInt() <= 255 }
            }
        }
    }

    // ============ Server Management ============
    fun favoriteServers(ctx: Context): Set<String> = prefs(ctx).getStringSet(KEY_FAVORITE_SERVERS, emptySet()) ?: emptySet()
    fun setFavoriteServers(ctx: Context, servers: Set<String>) = prefs(ctx).edit().putStringSet(KEY_FAVORITE_SERVERS, HashSet(servers)).apply()

    fun customServerNames(ctx: Context): Map<String, String> {
        val json = prefs(ctx).getString(KEY_CUSTOM_SERVER_NAMES, "{}") ?: "{}"
        return try {
            // Simple JSON parsing - in production use a proper JSON library
            emptyMap()  // Placeholder - use Gson/Moshi in real implementation
        } catch (e: Exception) {
            emptyMap()
        }
    }

    fun setCustomServerNames(ctx: Context, names: Map<String, String>) {
        // Placeholder - use Gson/Moshi in real implementation
        val json = "{}"  // Convert map to JSON
        prefs(ctx).edit().putString(KEY_CUSTOM_SERVER_NAMES, json).apply()
    }

    // ============ Auto-Reconnect Settings ============
    fun autoReconnectEnabled(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_AUTO_RECONNECT_ENABLED, true)
    fun setAutoReconnectEnabled(ctx: Context, value: Boolean) = prefs(ctx).edit().putBoolean(KEY_AUTO_RECONNECT_ENABLED, value).apply()

    fun maxRetryAttempts(ctx: Context): Int = prefs(ctx).getInt(KEY_MAX_RETRY_ATTEMPTS, 3)
    fun setMaxRetryAttempts(ctx: Context, value: Int) = prefs(ctx).edit().putInt(KEY_MAX_RETRY_ATTEMPTS, value.coerceIn(1, 5)).apply()

    // ============ Connect mode (Smart / Manual) ============
    // Defaults to MANUAL: anyone upgrading has already chosen a server, and Smart
    // mode silently connecting them somewhere else would be a surprise, not a
    // feature. Home's swipe gesture on the power button is what opts in.
    fun connectMode(ctx: Context): String =
        prefs(ctx).getString(KEY_CONNECT_MODE, MODE_MANUAL) ?: MODE_MANUAL

    fun setConnectMode(ctx: Context, value: String) =
        prefs(ctx).edit()
            .putString(KEY_CONNECT_MODE, if (value == MODE_SMART) MODE_SMART else MODE_MANUAL)
            .apply()

    // ============ Last flag country ============
    // The country whose flag Home's hero panel last washed across its top, kept so a
    // cold start opens on that flag instead of on a bare panel while the active
    // config, its geo and the artwork are still being loaded. It is a display cache,
    // not a selection: nothing routes by it, and Home drops it the moment there is no
    // saved server left to show a flag for.
    private const val KEY_LAST_FLAG_CC = "last_flag_country"

    fun lastFlagCountry(ctx: Context): String =
        prefs(ctx).getString(KEY_LAST_FLAG_CC, "") ?: ""

    fun setLastFlagCountry(ctx: Context, code: String) =
        prefs(ctx).edit().putString(KEY_LAST_FLAG_CC, code.trim().uppercase()).apply()

    // The last public IP that resolved successfully, kept so the hero opens on the last-known
    // address instead of a blank dash while a fresh lookup is still in flight — and so a censored
    // or captive network that blocks every lookup this session still shows the last good value.
    // A display cache only; nothing routes by it.
    private const val KEY_LAST_PUBLIC_IP = "last_public_ip"

    fun lastPublicIp(ctx: Context): String =
        prefs(ctx).getString(KEY_LAST_PUBLIC_IP, "") ?: ""

    // Only a well-formed IPv4 literal is ever persisted here. A malformed/partial value
    // (from a stale bug, a truncated lookup, etc.) used to be written through unchecked,
    // then read back on every future launch as `userIp` -- so a single bad write could
    // "stick" forever and show a broken address indefinitely, even after the code that
    // produced it was fixed. Anything that fails this check is simply not persisted, and
    // the field keeps whatever value it already had.
    fun setLastPublicIp(ctx: Context, ip: String) {
        val trimmed = ip.trim()
        if (!isValidIpv4(trimmed)) return
        prefs(ctx).edit().putString(KEY_LAST_PUBLIC_IP, trimmed).apply()
    }

    private fun isValidIpv4(value: String): Boolean {
        val parts = value.split(".")
        if (parts.size != 4) return false
        val octets = parts.map { it.toIntOrNull() }
        if (octets.any { it == null || it !in 0..255 } ) return false
        val o = octets.map { it!! }
        return when {
            o[0] == 0 -> false
            o[0] == 127 -> false
            o[0] == 10 -> false
            o[0] == 172 && o[1] in 16..31 -> false
            o[0] == 192 && o[1] == 168 -> false
            o[0] == 169 && o[1] == 254 -> false
            o[0] == 255 -> false
            else -> true
        }
    }


    // ============ Daily data usage (local, best-effort) ============
    // A client-side running total of bytes moved through the tunnel *today*, kept so
    // Home's usage ring can show a real daily figure rather than only the current
    // session (which resets on every connect/disconnect). This is a UI indicator, not
    // billing: it accumulates positive per-tick deltas the UI observes while connected,
    // persisted here so it survives the app being backgrounded/relaunched. It cannot
    // count traffic that flowed while the app process was dead, so treat it as a
    // best-effort local estimate. Rolls over to 0 at local midnight (day string change).
    private const val KEY_USAGE_DAY = "usage_day"       // "yyyy-MM-dd" in local time
    private const val KEY_USAGE_BYTES = "usage_bytes_today"

    private fun todayKey(): String =
        java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())

    /** Bytes used today so far. Returns 0 (and does not rewrite) once the stored day is stale. */
    fun usageBytesToday(ctx: Context): Long {
        val p = prefs(ctx)
        val storedDay = p.getString(KEY_USAGE_DAY, "") ?: ""
        return if (storedDay == todayKey()) p.getLong(KEY_USAGE_BYTES, 0L) else 0L
    }

    /**
     * Add [delta] bytes to today's running total and return the new total. Rolls the
     * counter over to [delta] when the stored day is not today. Non-positive deltas are
     * ignored (never decrement) so a session/counter reset can't subtract from the day.
     */
    fun addUsageBytes(ctx: Context, delta: Long): Long {
        if (delta <= 0L) return usageBytesToday(ctx)
        val p = prefs(ctx)
        val today = todayKey()
        val storedDay = p.getString(KEY_USAGE_DAY, "") ?: ""
        val base = if (storedDay == today) p.getLong(KEY_USAGE_BYTES, 0L) else 0L
        val total = base + delta
        p.edit().putString(KEY_USAGE_DAY, today).putLong(KEY_USAGE_BYTES, total).apply()
        return total
    }

    // ============ SUBSCRIPTIONS ============
    private const val KEY_SUBSCRIPTIONS = "subscriptions_json"
    
    /**
     * Get all saved subscriptions
     */
    fun getSubscriptions(ctx: Context): List<Subscription> {
        return try {
            val json = prefs(ctx).getString(KEY_SUBSCRIPTIONS, "[]") ?: "[]"
            // Simple JSON parse (without full Gson to keep it lightweight)
            // For now, return empty and implement when UI is ready
            emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }
    
    /**
     * Save all subscriptions
     */
    fun saveSubscriptions(ctx: Context, subscriptions: List<Subscription>) {
        try {
            // Serialize to JSON (simple format)
            val json = subscriptions.joinToString(",") { sub ->
                """{"id":"${sub.id}","name":"${sub.name}","url":"${sub.url}","lastUpdated":${sub.lastUpdated},"enabled":${sub.enabled}}"""
            }
            prefs(ctx).edit().putString(KEY_SUBSCRIPTIONS, "[$json]").apply()
        } catch (e: Exception) {
            android.util.Log.e("AppSettings", "Failed to save subscriptions", e)
        }
    }
    
    /**
     * Add a new subscription
     */
    fun addSubscription(ctx: Context, subscription: Subscription) {
        val current = getSubscriptions(ctx).toMutableList()
        current.add(subscription)
        saveSubscriptions(ctx, current)
    }
    
    /**
     * Remove subscription by ID
     */
    fun removeSubscription(ctx: Context, subscriptionId: String) {
        val current = getSubscriptions(ctx).filter { it.id != subscriptionId }
        saveSubscriptions(ctx, current)
    }
}

